public class ZooKeeperTest {
	
	public static void main(String[] args) {
		
		Gorilla g = new Gorilla();
		Bat b = new Bat();
		g.throwSomething();
		g.throwSomething();
		g.throwSomething();
		g.eatBananas();
		g.eatBananas();
		g.climb();
		b.attackTown();
		b.attackTown();
		b.attackTown();
		b.eatHumans();
		b.eatHumans();
		b.fly();
		b.fly();
	}
}
