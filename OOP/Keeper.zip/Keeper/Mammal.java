public class Mammal {
	int energy = 100;

	public int displayEnergy(){

		System.out.println("Energy Level " + energy);
		return energy;
	}
	

}

