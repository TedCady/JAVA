// import java.util.Scanner;

public class PythagoreanTest{
    public static void main(String[] args){
        Pythagorean id = new Pythagorean();
        double hypotenuse = id.calculateHypotenuse(4, 5);


        System.out.println(hypotenuse);
    }
}
        // var scanner = new Scanner(System.in);
        // int A = scanner.nextInt();
        // int B = scanner.nextInt();
        // double hypotenuse = new Pythagorean().calculateHypotenuse(A, B);
